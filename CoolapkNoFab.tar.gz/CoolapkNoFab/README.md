# CoolapkNoFab

隐藏酷安（com.coolapk.market）主界面底栏中间那个绿色「+」发布按钮的 LSPosed 模块（省电版）。

## 省电设计

| 做法 | 耗电 | 是否采用 |
| --- | --- | --- |
| Compose 函数级拦截（让加号不被合成） | 一次性 hook，只在酷安本来就要重组时生效，无轮询、无每帧回调 | ✅ 主方案 |
| 启动时最多 3 次控件树遍历（400ms / 1.2s / 3s，命中即停） | 每次启动几毫秒，之后无后台动作 | ✅ 备用方案 |
| 每 250ms 扫 10 秒的轮询 | 每次进主界面约 40 次遍历 | ❌ 已删除 |
| `dispatchDraw` 里挖洞 | 每帧都执行，持续开销 | ❌ 已删除 |

结论：正常使用时模块的功耗接近零——按钮被跳过后渲染量反而略降。

## 目录

```
CoolapkNoFab/
├─ settings.gradle.kts
├─ build.gradle.kts
├─ gradle.properties
├─ README.md
├─ .gitignore
├─ .github/workflows/build.yml      # 云端打包（推荐）
└─ app/
   ├─ build.gradle.kts
   └─ src/main/
      ├─ AndroidManifest.xml        # xposedmodule / xposedminversion 元数据
      ├─ assets/xposed_init         # 入口：dev.eta.coolapk.nofab.HookEntry
      └─ java/dev/eta/coolapk/nofab/HookEntry.java
```

## 云端编译（推荐，不用装 SDK）

1. 新建一个 GitHub 仓库（私有也行）。
2. 把 `CoolapkNoFab` 里的全部文件推到仓库根目录（网页版可以直接拖文件夹上传，注意包含
   `.github` 和 `.gitignore` 这类隐藏目录；用 git 推更稳妥）。
3. 进仓库 **Actions** → 左侧 `build` → **Run workflow**（push 也会自动跑）。
4. 跑完后在该次运行页面底部 **Artifacts** 下载 `CoolapkNoFab-apk.zip`，
   解压得到 `app-release.apk`。
5. 编译时间约 2–4 分钟，首次会下载 Gradle 和 AGP。

> 工作流用 `gradle/actions/setup-gradle` 提供 Gradle 8.7，不依赖仓库里的 wrapper，
> 所以不用提交 `gradle-wrapper.jar`。

想本地编译也行：装 JDK 17 + Android SDK 35，根目录 `gradle assembleRelease`，
产物在 `app/build/outputs/apk/release/app-release.apk`。

## 安装与启用

1. 安装 APK（显示为「酷安去加号」，没有桌面图标，属正常）。
2. LSPosed 管理器 → 启用该模块 → 作用域勾选「酷安」。
3. 强制停止酷安，重新打开（模块冷启动生效）。

## 如果没生效

模块会把控件树打到 logcat（tag `CoolapkNoFab`）：

```bash
su -c "logcat -s CoolapkNoFab -d"
```

- 出现 `命中 Composable ...，加号不再绘制` → 主方案生效。
- 出现 `已隐藏 ...` → 备用方案生效。
- 只出现 `未找到 ...LiquidNodeFloatingActionButtonKt` 且没有 `已隐藏` → 说明该类被 R8
  混淆了，把日志里真实出现的类名 / id 补进 `CLASS_KEYWORDS` / `ID_KEYWORDS` 再编一版即可。

## 已知限制

- 只处理主界面底栏；发布页、详情页不受影响。
- 主方案依赖酷安 Compose 类名未被混淆；被混淆时靠备用方案的关键字兜底。
- 个人自用模块，不做隐藏检测对抗。
