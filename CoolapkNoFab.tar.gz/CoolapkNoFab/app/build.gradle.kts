plugins {
    id("com.android.application")
}

android {
    namespace = "dev.eta.coolapk.nofab"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.eta.coolapk.nofab"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // 自用模块，直接用 debug 签名即可，LSPosed 不校验签名
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    // Xposed API 只用于编译，不进 APK
    compileOnly("de.robv.android.xposed:api:82")
}
