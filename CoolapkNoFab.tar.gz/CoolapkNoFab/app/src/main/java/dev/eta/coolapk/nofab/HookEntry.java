package dev.eta.coolapk.nofab;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;

import java.lang.reflect.Method;
import java.util.Locale;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * 酷安去加号（省电版）。
 *
 * 设计原则：不轮询、不挂每帧回调、不做常驻定时器。
 *
 *  1) 主方案：直接让绘制加号的 Composable 不执行。
 *     这是一次性的方法 hook，只在酷安本来就要重组时生效，跳过一个小按钮的合成
 *     反而更省电；界面重建也不会复活按钮。
 *
 *  2) 备用方案：仅在 MainActivity 首次显示时做最多 3 次控件树遍历（间隔 400ms/1.2s/3s，
 *     找到就停），覆盖传统 View 版底栏。总开销是一次启动几毫秒，之后完全没有后台动作。
 *
 * 原本的「每 250ms 扫 10 秒」循环和「dispatchDraw 里挖洞」都因为耗电已删除。
 */
public final class HookEntry implements IXposedHookLoadPackage {

    private static final String TAG = "CoolapkNoFab";
    private static final String TARGET_PKG = "com.coolapk.market";

    /** View 类名关键字（小写比较） */
    private static final String[] CLASS_KEYWORDS = {
            "floatingactionbutton", "floatingbuttondock", "publishbutton", "postbutton"
    };

    /** View id 关键字（小写比较） */
    private static final String[] ID_KEYWORDS = {
            "fab", "publish", "post_fab", "add_button", "button_publish"
    };

    /** 猜测的 Compose 函数类名（酷安 16.6.x 源码名，若未被混淆即可直接命中） */
    private static final String[] COMPOSE_CLASS_CANDIDATES = {
            "com.coolapk.market.widget.compose.liquid.LiquidNodeFloatingActionButtonKt",
            "com.coolapk.market.widget.compose.liquid.LiquidFloatingActionButtonKt",
            "com.coolapk.market.view.main.liquid.LiquidBottomNavigationKt",
    };

    /** 每个 Activity 实例只做一次轻量扫描 */
    private static final WeakHashMap<Activity, Boolean> SCANNED = new WeakHashMap<>();

    private static final boolean[] COMPOSE_HIT = {false};

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) {
            return;
        }
        XposedBridge.log(TAG + ": 已注入 " + lpparam.packageName
                + " (process=" + lpparam.processName + ")");

        hookComposeFunctions(lpparam);

        try {
            XposedBridge.hookAllMethods(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Activity activity = (Activity) param.thisObject;
                    if (activity == null) {
                        return;
                    }
                    // 只有主界面才有那条底栏，其它页面一律不碰
                    if (!activity.getClass().getName().endsWith("MainActivity")) {
                        return;
                    }
                    if (SCANNED.put(activity, Boolean.TRUE) != null) {
                        return;
                    }
                    scheduleLightScan(activity);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook onResume 失败: " + t);
        }
    }

    /* ---------------- 主方案：Compose 函数级拦截（零轮询） ---------------- */

    private static void hookComposeFunctions(XC_LoadPackage.LoadPackageParam lpparam) {
        for (String className : COMPOSE_CLASS_CANDIDATES) {
            Class<?> clazz = XposedHelpers.findClassIfExists(className, lpparam.classLoader);
            if (clazz == null) {
                XposedBridge.log(TAG + ": 未找到 " + className + "（可能已被混淆）");
                continue;
            }
            XposedBridge.log(TAG + ": 命中 " + className);
            for (Method m : clazz.getDeclaredMethods()) {
                if (!hasComposerParam(m)) {
                    continue;
                }
                final String name = m.getName().toLowerCase(Locale.ROOT);
                if (!name.contains("floating") && !name.contains("publish") && !name.contains("plus")) {
                    continue;
                }
                try {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam p) {
                            if (!COMPOSE_HIT[0]) {
                                COMPOSE_HIT[0] = true;
                                XposedBridge.log(TAG + ": 命中 Composable " + name + "()，加号不再绘制");
                            }
                            p.setResult(null);
                        }
                    });
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": hook " + m + " 失败: " + t);
                }
            }
        }
    }

    private static boolean hasComposerParam(Method m) {
        for (Class<?> c : m.getParameterTypes()) {
            if ("androidx.compose.runtime.Composer".equals(c.getName())) {
                return true;
            }
        }
        return false;
    }

    /* ---------------- 备用方案：启动时最多 3 次扫描 ---------------- */

    private static void scheduleLightScan(final Activity activity) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final int[] attempt = {0};
        final boolean[] logged = {false};
        final Runnable[] task = new Runnable[1];

        task[0] = new Runnable() {
            @Override
            public void run() {
                boolean hid = false;
                try {
                    View decor = activity.getWindow().peekDecorView();
                    if (decor != null) {
                        hid = hidePublishButtons(decor);
                        if (!logged[0]) {
                            logged[0] = true;
                            dumpTree(decor, 0);
                        }
                    }
                } catch (Throwable ignored) {
                }
                attempt[0]++;
                if (hid || attempt[0] >= 3) {
                    return;                 // 命中就停，最多 3 次，之后不再有任何后台动作
                }
                long delay = attempt[0] == 1 ? 800 : 1800;
                handler.postDelayed(task[0], delay);
            }
        };
        handler.postDelayed(task[0], 400);
    }

    private static boolean hidePublishButtons(View v) {
        if (v == null) {
            return false;
        }
        if (isPublishButton(v)) {
            if (v.getVisibility() != View.GONE) {
                v.setVisibility(View.GONE);
                XposedBridge.log(TAG + ": 已隐藏 " + v.getClass().getName()
                        + " id=" + idName(v) + " bounds=" + boundsOf(v));
            }
            return true;
        }
        boolean hid = false;
        if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            for (int i = 0; i < group.getChildCount(); i++) {
                hid |= hidePublishButtons(group.getChildAt(i));
            }
        }
        return hid;
    }

    private static boolean isPublishButton(View v) {
        String cls = v.getClass().getName().toLowerCase(Locale.ROOT);
        for (String k : CLASS_KEYWORDS) {
            if (cls.contains(k)) {
                return true;
            }
        }
        String id = idName(v).toLowerCase(Locale.ROOT);
        if (!id.isEmpty()) {
            for (String k : ID_KEYWORDS) {
                if (id.contains(k)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static String idName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID) {
                return "";
            }
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "";
        }
    }

    private static String boundsOf(View v) {
        int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        return loc[0] + "," + loc[1] + " " + v.getWidth() + "x" + v.getHeight();
    }

    /** 只打一次控件树，方便定位真正的按钮（logcat -s CoolapkNoFab）。 */
    private static void dumpTree(View v, int depth) {
        if (depth > 12) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            sb.append("  ");
        }
        sb.append(v.getClass().getName());
        String id = idName(v);
        if (!id.isEmpty()) {
            sb.append(" #").append(id);
        }
        sb.append(" [").append(boundsOf(v)).append(']');
        if (v.getContentDescription() != null) {
            sb.append(" desc=").append(v.getContentDescription());
        }
        XposedBridge.log(TAG + ": " + sb);
        if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            for (int i = 0; i < group.getChildCount(); i++) {
                dumpTree(group.getChildAt(i), depth + 1);
            }
        }
    }
}
